# SimActivationPortal
Allows user to activate sim details by verifying details such as Aadhar card and address details.
